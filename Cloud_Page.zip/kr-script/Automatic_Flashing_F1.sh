cache
dalvik
system
vendor
data
