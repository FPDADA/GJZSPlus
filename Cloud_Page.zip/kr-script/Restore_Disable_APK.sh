#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


Option=`pm list packages -d | sed 's/.*://g'`
print_apk_list
