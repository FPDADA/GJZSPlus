#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


[[ $lock = 1 ]] && fastboot flashing lock
[[ $lock = 2 ]] && fastboot oem lock
