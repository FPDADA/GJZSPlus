#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


if [[ $SDK -ge 29 ]]; then
    echo 0
else
    echo 1
fi
